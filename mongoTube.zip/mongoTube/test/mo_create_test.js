const Student = require('../app/student');

const assert = require('assert');

describe('create tests for mongodb', () =>{
    it('create a user in DB',() => {
        const stu = new Student({name:'Pushpanjali'});
        stu.save()
            .then(() => {
                assert(!stu.isNew);
            })
            .catch((error) => {
                console.log("error caught",error);
            })
        
    });
});

// Reading records from DB tests.

describe("Read Tests",() => {
    let reader;
    beforeEach((done) => {
        reader = new Student({name:"Reader"});
        reader.save()
            .then(() => {
                //assert(!reader.isNew);
                done();
            })
            .catch((error) => {
                console.log("error caught",error);
            });
    });

    it("Read a user: Reader",(done) => {
        Student.find({name:"Reader"})
            .then((students) => {
                //_is is a BSON value
                assert(reader._id.toString() === students[0]._id.toString() );
                done();
            });
    });
});

//All delete tests

describe("delete tests",() => {

    let deleter;
    beforeEach((done) => {
        deleter = new Student({name:"Deleter"});
        deleter.save()
            .then(() => {
                //assert(!deleter.isnew);
                done();
            })
            .catch((error) => {
                console.log("error caught",error);
            });
    });

    it("delete test for deleter", (done) => {
        Student.findByIdAndDelete(deleter._id)
            .then(() => Student.findOne({name:"Deleter"}))
            .then((student) => assert(student === null))
            done();
    });
})

//All update tests

describe("Update test", () => {
    let updater;
    beforeEach((done) => {
        updater = new Student({name:"Updater"});
        updater.save()
            .then(() => {
                done();
            })
            .catch((error) => {
                console.log("error caught",error);
            });
    });
    it("Set and Save test",() => {
        updater.set('name','UpUpdater');
        updater.save()
            .then(() => Student.find({}))
            .then((students) => {
                assert(students[0].name !== "Updater");
                //done();
            })
    })
})